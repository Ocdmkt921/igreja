<?php

    function getSegments() {

        return array(
            'mauticform_sabado11079h00' => 2,
            'mauticform_sabado110710h45' => 3,
            'mauticform_domingo120719h00' => 4
        );

    }

    function getSchedule() {

        return array(
            2 => 'Sábado as 9h00',
            3 => 'Sábado as 10h45',
            4 => 'Domingo as 19h00'
        );

    }