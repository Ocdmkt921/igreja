<?php

    $config = array(
        'hostname' => 'localhost',
        'username' => 'tsmai587_webuser',
        'password' => 'webuser9009',
        'database' => 'tsmai587_igreja'
    );