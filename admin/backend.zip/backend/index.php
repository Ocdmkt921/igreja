<?php

    include './connection.php';


    class DefaultController {

        private $conn;

        function __construct()
        {

            $this->conn = connection();
            
        }

        

    }

    try {

        $action = $_GET['action'];
        $method = strtolower($_SERVER['REQUEST_METHOD']);
        
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
        header("Access-Control-Allow-Headers: X-Requested-With, Content-Type, X-Token-Auth, Authorization, x-store-code, x-xsrf-token");

        if($method === 'options' )
            exit;
        
        $resources = array(
            'sms' => array(
                'post' => 'sendSMS',
                'get' => 'getSMSs'
            ),
        );

        if(!array_key_exists($action, $resources))
            throw new \Exception('Recurso não encontrado');

        $actions = $resources[$action];

        if(!array_key_exists($method, $actions))
            throw new \Exception('Ação não encontrada');

        $controller = new DefaultController();
        $function = $actions[$method];
        $result = $controller->$function();

        header("content-type: application/json");
        echo json_encode($result);

    } catch(\Exception $err) {
        http_response_code(500);
        echo $err->getMessage();
    }